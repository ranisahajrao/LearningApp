const { response } = require('express')
const express = require('express')
const app = express()
const port = 8081
const db = require('./queries')
const dbcors = require('./coursesqueries')
const cors = require('cors')

app.use(express.urlencoded({extended : true}))
app.use(express.json())
app.use(cors())

app.get('/',(request,response) =>{
    response.send("Konverge DB Service")
    //response.json("Hello Snehal")
})

app.get('/login',(request,response) =>{
    response.send("Display Login Page")
})

//Routes reagrding Users(userlogin)
app.get('/getusers', db.getusers)
app.get('/users/:id', db.getUserByID)
app.post('/loginauth', db.getLoginUser)
app.post('/adduser', db.createUser)
app.put('/updateuser', db.updateUser)
app.delete('/deleteuser/:id', db.deleteUser)

//Routes regarding Courses and Sessions
app.get('/getcourses', dbcors.getCourses)
app.post('/addcourse', dbcors.addCourse)
app.get('/getsessions/:id', dbcors.getSessions) 
app.put('/updatecourse/:selectcourse', dbcors.updateCourse)
app.delete('/delcourse/:selectcourse', dbcors.delCourse)

app.listen(port,()=>{
    console.log(`Example app Listening at http://localhost:${port} `)
})